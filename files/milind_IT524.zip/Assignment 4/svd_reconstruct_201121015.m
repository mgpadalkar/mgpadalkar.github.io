%   Computer Vision (IT524)
%   Assignment 4
%   Compare an image and its compressed version obtained by setting all the
%   small eigenvalues to 0 (obtained using SVD of the image)
%--------------------------------------------------------------------------
%   Created by: Milind Padalkar (201121015)
%   Date: 12-10-2012
%--------------------------------------------------------------------------

%% Function help
%   Input   :   1. Compression ratio (default = 0.5)
%               2. Input image
%   Output  :   1. Compressed Image
%   Usage   :   A = svd_reconstruct_201121015(num_val,img)

%% Function starts
function A = svd_reconstruct_201121015(num_val,img)

%% Parameter defaults

if(exist('num_val','var')==0)
    num_val = 0.5;
end

if(exist('img','var')==0)
    img = double(imread('1.png'));
end

%% Copy to output image
out_img = 0.*img;

%% Input image and SVD
for pln = 1:size(img,3)
    A = img(:,:,pln);
    [U S V] = svd(A);
    
    %% Set num_val proportion of eigenvalues to 0 and reconstruct the image
    diagS = min(size(S,1),size(S,2));
    num_zero = round(diagS*num_val);
    
    Sout = S;
        
    for px = (diagS-num_zero+1):diagS
        Sout(px,px) = 0;
    end
        
    % Reconstruction
    Aout = U*Sout*V';
    out_img(:,:,pln) = Aout;
end

%% Show images
hdl_in = figure; imshow(uint8(img)), title('Input Image');
hdl_out = figure; imshow(uint8(out_img)), title(sprintf('Compressed Image with ratio = %f',num_val));

%% Save results
print(hdl_in,'-v','-dpng', sprintf('./1_input.png'));
print(hdl_out,'-v','-dpng', sprintf('./1_%f.png',num_val));
close all;
