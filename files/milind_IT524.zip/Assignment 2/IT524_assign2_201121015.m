%   Computer Vision (IT524)
%   Assignment 2: Assume different source positions and find the resulting
%   image of a given sphere.
%   Assume different source positions as (ps,qs) = (0,0), (0.5,0.5) etc in
%   the image coordinate system
%   Created by: Milind Padalkar (201121015)
%   Date: 22-08-2012
%% Clear workspace
clear;
close all;
clc;

%% Set Parameters
rds = 200;           % Sphere's radius
sz = 512;            % Image size
p_s = [0,0.5,0];      % Source p_s
q_s = [0,0.5,1];      % Source q_s

%% Circle initialization
if(mod(sz,2)==0)
    mid = sz/2;
else
    mid = floor(sz/2) + 1;
end
sphr = zeros(sz,sz);

%% Draw the sphere
for j = 1:sz
    y = mid - j;
    for i = 1:sz
        x = mid - i;
        if(x*x + y*y <= rds*rds)
            sphr(i,j) = 1;
        end
    end
end
hdl_sphr = figure; imshow(sphr), title('Sphere in 2D');
print(hdl_sphr,'-v','-dpng','Sphere.png');

%% Calculating p and q and finally R(p(x,y),q(x,y)) = E(x,y)
%   Given
%   1. p = -x/(z-z0)
%   2. q = -y/(z-z0)
%   3. (z-z0)^2 + (x^2+y^2) = r^2
%   Thus,
%   E(x,y) = (p*p_s + q*q_s + 1)/(sqrt(p_s^2+q_s^2+1)*sqrt(p^2+q^2+1))
%
%          = ((-x/(z-z0))*ps + (-y/(z-z0))*qs + 1)
%            ---------------------------------------------------------------
%            ((sqrt(p_s^2+q_s^2+1)*sqrt((-x/(z-z0))^2+(-y/(z-z0))^2+1))
%
%   Therefore,
%   E(x,y) = (-x*p_s - y*q_s + (z-z0))/(r*sqrt(p_s*p_s+qs*q_s+1))
for srcs = 1:size(p_s,2)
    E = zeros(sz,sz);
    ps = p_s(srcs);
    qs = q_s(srcs);
    for j = 1:sz
        y = mid - j;
        for i = 1:sz
            x = mid - i;
            if(x*x + y*y <= rds*rds)
                z_z0 = sqrt(rds*rds-(x*x + y*y));
                E(i,j) = (-x*ps-y*qs+z_z0)/(rds*sqrt(ps*ps+qs*qs+1));
            end
        end
    end
    
    % Display
    wintitle = sprintf('E(x,y) for source (ps,qs) = (%.1f,%.1f)',ps,qs);
    hdl = figure; imshow(E), title(wintitle);
    
    % Save
    print(hdl,'-v','-dpng',sprintf('Source_%d.png',srcs));
end