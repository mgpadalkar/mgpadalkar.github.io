%% Code for demonstrating bilinear interpolation
% Date      : 02-08-2012
% Creator   : Milind Padalkar
%   Inputs  :   1. Array of 4 available values [p1,p2,p3,p4],
%                  where each p is [R G B]
%                  i.e. 'P_mat' = [r1 g1 b1;r2 g2 b2;r3 g3 b3; r4 g4 b4]
%               2. Horizontal and vertical distances [ht,wd]
%                  Such that
%
%            (0,0,0)                            (255,0,0)
%                  P1<---------(wd)----------->P2
%                   |                           |
%                   |                           |
%                   |                           |
%                  (ht)                        (ht)
%                   |                           |
%                   |                           |
%                   |                           |
%                   P4<---------(wd)----------->P3
%            (0,0,255)                          (255,255,255)
%
%                  Capitals represent the actualy point, while lower case
%                  letters represent their corresponding values.
%
%   Outputs :   1. Matrix of interpolated values

%% Starting here
function pt_val = IT524_bilinear_interpolate()
% clear;
% close all;
% clc;

%% Some theory
% In linear interpolation, for any given points 'P' and 'Q' with values
% 'p' and 'q' at 'T' units apart, a 'R' also lies on the line joining
% 'P' and 'Q', and at 't' units from 'P' has a value given by
% r = {[(q-p)/T]*(t) + p}
%
% For bilinear interpolationi, if we now consider a point 'R12' between 'P1'
% and 'P2' at a distance 'y1' from 'P1', we can calculate 'r12' as
% r12 = {[(p2-p1)/wd]*(y1) + p1}--------------------------------------(1)
% Visualization: P1<-------------R12---------------->P2
%                  |<---(y1)---->|
%                  |<--------------(wd)------------->|
%
% Similarly, a point 'R43' exactly at 'y1' from 'P4' and between 'P4' and
% 'P3' can be calculated as
% r43 = {[(p3-p4)/wd]*(y1) + p4}--------------------------------------(2)
% Visualization: P4<-------------R43---------------->P3
%                  |<---(y1)---->|
%                  |<--------------(wd)------------->|
%
% Now, any point R at a distance 'y1' from 'R12' and between 'R12','R43' is
% actually at a distance (x1,y1) from 'P1' and can be calculated as
% r = {[(r43-r12)/ht]*(x1) + r12}-------------------------------------(3)
% Visualization: % R12  _   _
%                   |   |   |
%                   |  (x1) |
%                   |   |   |
%                  (R)  -   |
%                   |      (ht)
%                   |       |
%                   |       |
%                  R43      -
%
% From equation (1),(2) and (3) we can calculate value of all points 'R'
% which are actually bounded by the rectangle 'P1'-'P2'-'P3'-'P4'

%% Working out to interpolate value of T-1 points between two given points
P_mat = input('Enter P_mat : ');
HT_WD = input('Enter HT_WD: ');
ht = HT_WD(1);
wd = HT_WD(2);

% Create space for storing values
pt_val = zeros(ht,wd,3);
pt_val(1,1,:) = P_mat(1,:);       % P1
pt_val(1,wd,:) = P_mat(2,:);      % P2
pt_val(ht,wd,:) = P_mat(3,:);     % P3
pt_val(ht,1,:) = P_mat(4,:);      % P4

% Calculate value of all intermediate points
r12 = zeros(1,3);
r43 = zeros(1,3);
r = zeros(1,3);
for WD = 1:wd
    y1 = WD-1;
    for color = 1:3
        r12(1,color) = ((pt_val(1,wd,color)-pt_val(1,1,color))/(wd-1))*(y1) + pt_val(1,1,color);
        r43(1,color) = ((pt_val(ht,wd,color)-pt_val(ht,1,color))/(wd-1))*(y1) + pt_val(ht,1,color);
    end
    for HT = 1:ht
        if( ((WD==1 || WD==wd) && HT==1) || ((WD==1 || WD==wd) && HT==ht) )
            % Skip
        else
            x1 = HT-1;
            for color = 1:3
                r(1,color) = ((r43(1,color)-r12(1,color))/(ht-1))*(x1) + r12(1,color);
            end
            pt_val(HT,WD,:) = r;
            pt_val(1,WD,:) = r12;
            pt_val(ht,WD,:) = r43;
        end
    end
end

%% Display
figure, imshow(uint8(pt_val)), title('Bilinear Interpolation');