%--------------------------------------------------------------------------
function cur_A_row = getNNrowVecSP(rX,rY,in_map,startX,startY)
%% Function to select the index of the nearest integral neighbour in a
% row-vector, corresponding to a given real (fractional) coordinate.
%   Inputs      :   1. X-coordinate (Real)
%                   2. Y-coordinate (Real)
%                   3. Large matrix from which index is to be selected
%                   4. Starting X-coordinate of the corresponding smaller
%                   matrix
%                   5. Starting Y-coordinate of the corresponding smaller
%                   matrix
%               Thus, the pixel (rX,rY) is located at in_map(startX+rX,startY,rY)
%   Outputs      :  1. A row vector having 1 at index of (rX,rY) in
%                      'in_map', with all other elements = 0
%   Usage        : cur_A_row = getNNrowVec(rX,rY,in_map,startX,startY)
%--------------------------------------------------------------------------

%% Get nearest low neighbour (i.e. Top Left)
low_intX = floor(rX);
low_intY = floor(rY);

%% Calculate distance of (rX,rY) from Top Left Neighbour
dx = rX - low_intX;
dy = rY - low_intY;

%% Get Neighbour-distance matrix such that [x,y,distance]
ngbr = zeros(4,3);
% Top left
ngbr(1,1) = low_intX;
ngbr(1,2) = low_intY;
% Top right
ngbr(2,1) = low_intX;
ngbr(2,2) = low_intY + 1;
% Bottom right
ngbr(3,1) = low_intX + 1;
ngbr(3,2) = low_intY + 1;
% Bottom left
ngbr(4,1) = low_intX + 1;
ngbr(4,2) = low_intY;

%% Calculate distances
ngbr(1,3) = sqrt(dx.^2 + dy.^2);
ngbr(2,3) = sqrt(dx.^2 + (1-dy).^2);
ngbr(3,3) = sqrt((1-dx).^2 + (1-dy).^2);
ngbr(4,3) = sqrt((1-dx).^2 + dy.^2);

%% Find nearest neighbour
nn = sortrows(ngbr,3);
nnx = nn(1,1);
nny = nn(1,2);

%% Select index of this neighbour
in_map = sparse(0.*in_map);
in_map((nnx+startX),(nny+startY)) = 1;
cur_A_row = reshape(in_map,1,numel(in_map));