%% Code for demonstrating linear interpolation
% Date      : 01-08-2012
% Creator   : Milind Padalkar
%   Inputs  :   1. Starting value 'p'
%               2. Ending value 'q'
%               3. Units ('T') i.e. values to reach from 'p' and 'q'
%                  i.e. (T-1) values are to be found between p and q
%   Outputs :   1. Set of interpolated values
%               2. Visualization set

%% Starting here
function [pt_val,pt_Val] = IT524_linear_interpolate()
% clear;
% close all;
% clc;

%% Some theory
% Given points 'P' and 'Q' with values 'p' and 'q' at 'T' units apart,
% we intend to find the value 'r' of a point 'R' between them (or anywhere on 
% the line joining 'P' and 'Q') which is at 't' units from 'P'
%--------------------------------------------------------------------------
% The increment in value from 'p' to 'q' takes 'T' units. Thus, in 1 unit,
% the increment is (q-p)/T. --------------------------------------------(1)
% Thus, T-1 represnets the number of units between 'P' and 'Q'.
% Now, since 'R' also lies on the line joining 'P' and 'Q', the increment 
% in 1 unit can also be given by (r-p)/t.-------------------------------(2)
% Since (1) and (2) represent the same quantity, the only unknown is now
% 'r' and can be calculated as r = {[(q-p)/T]*(t) + p}

%% Working out to interpolate value of T-1 points between two given points
p = input('Enter p : ');
q = input('Enter q: ');
T = input('Enter T: ');

% Create space for storing values
pt_val = zeros(1,(T+1));        % There are in all T+1 points ('P', '(T-1)intermediate points', 'Q')
pt_val(1) = p;
pt_val(T+1) = q;

% Calculate value of all intermediate points
for t = 1:T-1
    r = ((q-p)/T)*(t) + p;
    pt_val(t+1) = r;            % t+1 for adjustment as elements start from index 1 in Matlab
end

% Visualization
pt_Val = pt_val(ones(20,1),:);
t_scale = (255-0)/(q-p);
imshow(uint8(pt_Val.*t_scale));