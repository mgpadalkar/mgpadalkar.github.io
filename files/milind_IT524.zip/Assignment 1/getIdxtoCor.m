function [X,Y] = getIdxtoCor(Idx,ht)
%% Function to get pixel coordinates given its index in image of height 'ht'
%   Inputs      :   1. Index
%               :   2. Image height
%   Output      :   1. X-coordinate (Row)
%               :   2. Y-coordinate (Col)
%   Usage       :   [X,Y] = getIdxtoCor(Idx,ht,wd)
%% Implementation
Y = mod((Idx-1),ht) + 1;
X = floor((Idx-1)/ht) + 1;