%--------------------------------------------------------------------------
function cur_A_row = getBLrowVecSP(rX,rY,in_map,startX,startY)
%% Function to select the index of the bilinear interpolation using integral
% neighbours in a row-vector, corresponding to a given real (fractional) coordinate.
%   Inputs      :   1. X-coordinate (Real)
%                   2. Y-coordinate (Real)
%                   3. Large matrix from which index is to be selected
%                   4. Starting X-coordinate of the corresponding smaller
%                   matrix
%                   5. Starting Y-coordinate of the corresponding smaller
%                   matrix
%               Thus, the pixel (rX,rY) is located at in_map(startX+rX,startY,rY)
%   Outputs      :  1. A row vector having 1 at index of (rX,rY) in
%                      'in_map', with all other elements = 0
%   Usage        : cur_A_row = getBLrowVecSP(rX,rY,in_map,startX,startY)
%   Assumption   : Distance between available adjecent neighbours is 1
%--------------------------------------------------------------------------

%% Some theory
% For the following geometry,
%      |<-----ty---->|
%   ---A-------------|---------------------B
%    | |                                   |
%    | |                                   |
%   tx |                                   |
%   _|_|             T                     |
%      |                                   |
%   ---C-------------|---------------------D
%
% We have,
% T = A*[ty*tx - tx - ty + 1] + B*[-ty*tx + ty] + C*[-ty*tx + tx] + D*[ty*tx]

%% Get the 4 available neighbours
A = [floor(rX),floor(rY)];
B = [A(1,1),A(1,2)+1];
C = [A(1,1)+1,A(1,2)];
D = [A(1,1)+1,A(1,2)+1];

%% Calculate distance of (rX,rY) from Top Left Neighbour
tx = rX - A(1,1);
ty = rY - A(1,2);

%% Calculate coefficients of each neighbour
coef_A = ((tx*ty)-tx-ty+1);
coef_B = ((-ty*tx)+ty);
coef_C = ((-ty*tx)+tx);
coef_D = (ty*tx);

%% Assign these coefficients to the respective indices
in_map = sparse(0.*in_map);
in_map((A(1,1)+startX),(A(1,2)+startY)) = coef_A;
in_map((B(1,1)+startX),(B(1,2)+startY)) = coef_B;
in_map((C(1,1)+startX),(C(1,2)+startY)) = coef_C;
in_map((D(1,1)+startX),(D(1,2)+startY)) = coef_D;

cur_A_row = reshape(in_map,1,numel(in_map));