function [out_img,A_mat] = sp_rot_bilinear_hgs_fn(in_img,theta)
%% Program to rotate image using nearest-neighbour interpolation and a
% homogeneous equation i.e. Output = A*Input. Function to perform image
% rotation for a given angle "theta" about the center of the image.
% *************************************************************************
% **May take long time for large image size (even 256x256)*****************
% *************************************************************************
%--------------------------------------------------------------------------
% Perform image rotation in the follwing steps
% 1. Translate the image center to the origin
% 2. Rotate about the origin
% 3. Translate the origin to its original location
% 4. Create the transformation matrix for Nearest-Neighbour Interpolation
% 5. vec(Output) = A*vec(Input)
% 5. Reshape vec(Output) to get the final output
%--------------------------------------------------------------------------
%   Inputs   :      1. Input image (in_img)
%                   2. Angle of rotation in degrees (theta)
%   Outputs  :      1. Rotated image (out_img) in "double" format
%                   2. Transformation Matrix (A_mat)
%   Usage    :      [out_img,A_mat] = rot_nearest_hgs_fn(in_img,theta)

%% Set default parameters
if(exist('theta','var')==0)
    theta = 90;                  % Angle of rotataion in degrees
end
theta = mod(theta,360);

%% Set image
[rows,cols,dp] = size(in_img);
if(dp>1)
    in_img = rgb2gray(in_img);
end
pd_ht = round(rows/2);
pd_wd = round(cols/2);

% Perform zeropadding 
pd_img = zeros((rows+2*pd_ht),(cols+2*pd_wd));
pd_img(pd_ht+1:pd_ht+rows,pd_wd+1:pd_wd+cols) = in_img;

%% Combination of steps 1,2,3 gives us the following equation
% [x1;y1] = [cos(theta) sin(theta); -sin(theta) cos(theta)]*[x-x0;y-y0] + [x0;y0]
% x0 = ht/2, y0 = wd/2
x0 = round(rows/2);
y0 = round(cols/2);
Rot_mat = [cosd(theta) sind(theta); -sind(theta) cosd(theta)];

%% Here, we actually know (x1,y1) as they are the coordinates of the
% rotated image. Thus, we need to find (x,y) i.e. coordinates in the input
% image, from which (x1,y1) are calculated. Thus, the above equation needs
% to be modified as follows
% Let R = [cos(theta) sin(theta); -sin(theta) cos(theta)]
% Thus, [x1-x0;y1-y0] = R*[x-x0;y-y0]
% i.e. inv(R)*[x1-x0;y1-y0] = inv(R)*R*[x-x0;y-y0]
% i.e. inv(R)*[x1-x0;y1-y0] = [x-x0;y-y0]
% i.e. inv(R)*[x1-x0;y1-y0] + [x0;y0] = [x;y]
% i.e. [x;y] = inv(R)*[x1-x0;y1-y0] + [x0;y0]
% If (x,y) are integers, then the value can be directly copied from (x,y) to (x1,y1)
% else value at (x1,y1) can be interpolate using neighbours of (x,y)
invRot_mat = pinv(Rot_mat);

%% Generate a matrix of all coordinates such that newXY = [xa ya;xb yb;...;xn,yn]'
xrows = 1:rows;
ycols = 1:cols;

xRows = xrows(ones(cols,1),:);
xRows = reshape(xRows',1,numel(xRows));

yCols = ycols(ones(rows,1),:);
yCols = reshape(yCols,1,numel(yCols));

newXY = [xRows;yCols];

X0Y0 = [x0 y0];
X0Y0 = X0Y0(ones(size(newXY,2),1),:)';

%% Calculate the new coordinates
XY = invRot_mat*(newXY-X0Y0) + X0Y0;

%% Create the transformation matrix in the homogeneous form
A_mat = spalloc(numel(in_img),numel(pd_img),4*numel(in_img));
fprintf('Creating transformation matrix. Please be patient...');
for elm = 1:size(XY,2)
    rX = XY(1,elm);
    rY = XY(2,elm);
    A_mat(elm,:) = getBLrowVecSP(rX,rY,pd_img,pd_ht,pd_wd);
end
fprintf('Done!\n');

%% Reshape Input
pd_img = reshape(pd_img,numel(pd_img),1);

%% Perform Transformation
out_img = A_mat*pd_img;

%% Reshape output
out_img = reshape(out_img,rows,cols);

%% Display output
% hdl_in = figure; imshow(in_img), title('Input Image');
% print(hdl_in,'-v','-dpng', sprintf('./nn_input.png'));
hdl_out = figure; imshow(uint8(out_img)), title(sprintf('Rotated image at angle = %d degrees',theta));
% print(hdl_out,'-v','-dpng', sprintf('./nn_%d.png',theta));

%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
function cur_A_row = getBLrowVecSP(rX,rY,in_map,startX,startY)
%% Function to select the index of the bilinear interpolation using integral
% neighbours in a row-vector, corresponding to a given real (fractional) coordinate.
%   Inputs      :   1. X-coordinate (Real)
%                   2. Y-coordinate (Real)
%                   3. Large matrix from which index is to be selected
%                   4. Starting X-coordinate of the corresponding smaller
%                   matrix
%                   5. Starting Y-coordinate of the corresponding smaller
%                   matrix
%               Thus, the pixel (rX,rY) is located at in_map(startX+rX,startY,rY)
%   Outputs      :  1. A row vector having 1 at index of (rX,rY) in
%                      'in_map', with all other elements = 0
%   Usage        : cur_A_row = getBLrowVecSP(rX,rY,in_map,startX,startY)
%   Assumption   : Distance between available adjecent neighbours is 1
%--------------------------------------------------------------------------

%% Some theory
% For the following geometry,
%      |<-----ty---->|
%   ---A-------------|---------------------B
%    | |                                   |
%    | |                                   |
%   tx |                                   |
%   _|_|             T                     |
%      |                                   |
%   ---C-------------|---------------------D
%
% We have,
% T = A*[ty*tx - tx - ty + 1] + B*[-ty*tx + ty] + C*[-ty*tx + tx] + D*[ty*tx]

%% Get the 4 available neighbours
A = [floor(rX),floor(rY)];
B = [A(1,1),A(1,2)+1];
C = [A(1,1)+1,A(1,2)];
D = [A(1,1)+1,A(1,2)+1];

%% Calculate distance of (rX,rY) from Top Left Neighbour
tx = rX - A(1,1);
ty = rY - A(1,2);

%% Calculate coefficients of each neighbour
coef_A = ((tx*ty)-tx-ty+1);
coef_B = ((-ty*tx)+ty);
coef_C = ((-ty*tx)+tx);
coef_D = (ty*tx);

%% Assign these coefficients to the respective indices
in_map = sparse(0.*in_map);
in_map((A(1,1)+startX),(A(1,2)+startY)) = coef_A;
in_map((B(1,1)+startX),(B(1,2)+startY)) = coef_B;
in_map((C(1,1)+startX),(C(1,2)+startY)) = coef_C;
in_map((D(1,1)+startX),(D(1,2)+startY)) = coef_D;

cur_A_row = reshape(in_map,1,numel(in_map));