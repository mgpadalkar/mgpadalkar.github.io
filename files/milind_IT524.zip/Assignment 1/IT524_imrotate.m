%% Code for demonstrating image rotation
% Date      : 13-08-2012
% Creator   : Milind Padalkar
%   Inputs  :   1. 2D graylevel input image (I_img)
%               2. Angle of rotation in degrees (r_angle)
%   Outputs :   1. Rotated image (R_img)

%% Starting here
% function  R_img = IT524_imrotate(I_img,r_angle)
clear;
close all;
clc;

I_img = imread('cameraman.tif');
r_angle = 5;

r_angle = mod(r_angle,360);

%% Some theory
% Let angle between y-axis (horizontal) and line from origin joining an
% image point P(x,y) is Phi. Now let this point get shifted to P'(x',y')
% due to rotation such that, the angle between lines from origin to these
% points be Theta. If 'r' is the length of the segment from origin to these
% two points, we have
% x' = r*cos(Theta+Phi)
%      r*(cos(Theta)*cos(Phi)-sin(Theta)*sin(Phi)) 
%      x*cos(Theta) - y*sin(Theta) ==============> x=r*cos(Phi),y=r*sin(Phi)
% Similarly,
% y' = x*sin(Theta) + y*cos(Theta)
% Thus, value at any point P(x,y) is transfered to a point P'(x',y') using
% the following relation
% [x';y'] = [cos(Theta) -sin(Theta);sin(Theta) cos(Theta)]*[x;y]

%% Get image dimensions
[ht,wd,dp] = size(I_img);

%% Coordinate matrix
y = 1:wd;
x = 1:ht;

Xrow = x(ones(wd,1),:);
Xrow = reshape(Xrow,1,numel(Xrow));

Yrow = y(ones(ht,1),:);
Yrow = reshape(Yrow',1,numel(Yrow));

XY = [Xrow;Yrow];

rot_mat = [cosd(r_angle) -1*sind(r_angle);...
           sind(r_angle) cosd(r_angle)];
       
newXY = round(rot_mat*XY);

%% Calculate height and width of the rotated image
ht1 = round(max(newXY(1,:)) - min(newXY(1,:))) + 1;
wd1 = round(max(newXY(2,:)) - min(newXY(2,:))) + 1;

%% Translate the indices such that the minimum has index 1
newXY(1,:) = newXY(1,:) - min(newXY(1,:)) + 1;
newXY(2,:) = newXY(2,:) - min(newXY(2,:)) + 1;

%% Create an empty rotated image and perform mapping accordingly
R_out = uint8(-1*ones(ht1,wd1));
for elm = 1:size(newXY,2)
    x1 = newXY(1,elm);
    y1 = newXY(2,elm);
    x0 = XY(1,elm);
    y0 = XY(2,elm);
    R_out(x1,y1) = I_img(x0,y0);
end
figure, imshow(R_out);