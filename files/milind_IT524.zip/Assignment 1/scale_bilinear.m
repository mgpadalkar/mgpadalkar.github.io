%--------------------------------------------------------------------------
function out_img = scale_bilinear(in_img,scale_ft)
%% Program to up-scale a gray-scale image using bilinear interpolation
%   Inputs      :       1. Input image                                       [in_img]
%               :       2. Scaling factor >= 1 and integer (Default = 2)     [scale_ft]
%   Outputs     :       1. Scaled Image (2D Gray-scale in double format)     [out_img]
%   Usage       :       out_img = scale_bilinear(in_img,scale_ft)
%% Extract parameters and set defaults
if(exist('scale_ft','var')==0)
    scale_ft = 2;
else
    if(scale_ft < 1)
        fprintf('Can perform scaling only for integer values >= 1\n Scaling by factor 2.\n');
        scale_ft = 2;
    else
        if(scale_ft~=floor(scale_ft))
            scale_ft = floor(scale_ft);
            fprintf('Can perform scaling only for integer values >= 1\n Scaling by factor %d.\n',scale_ft);
        end
    end
end
in_img = double(in_img);

%% Create empty output image
[in_rows,in_cols,dp] = size(in_img);
if(dp>1)
    in_img = rgb2gray(in_img);
end
rows = in_rows*scale_ft;
cols = in_cols*scale_ft;
out_img = zeros(rows,cols);

%% Fill the output image using
% a. Existing values for integral multiples of scale_ft
% b. Bilinear interpolation for all other values
% Some notations used below:
% 1. flag: Gives increment from the lower row or column
% 2. int : Gives the integer value of lower-boud coordinate from the input image
% 3. real: Gives fractional coordinate value from the input image
for wd = 1:cols
    yflag = mod(wd-1,scale_ft);         
    yint = floor((wd-1)/scale_ft) + 1;
    yreal = yint + (yflag/scale_ft);    
    for ht = 1:rows
        xflag = mod(ht-1,scale_ft);
        xint = floor((ht-1)/scale_ft) + 1;
        xreal = xint + (xflag/scale_ft);
        % Check if both row and column are integral multiples of 'scale_ft'
        if(xflag==0 && yflag==0)
            % Copy from the integer position of the input image
            out_img(ht,wd) = in_img(xint,yint);
        else
            % Interpolate using the real (factional) position in the original image
            out_img(ht,wd) = mgp_bilinear_interpolate(in_img,xreal,yreal);
        end
    end
end

% %% Display
% figure, imshow(uint8(out_img));
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
function px_val = mgp_bilinear_interpolate(img,x,y)
%% Function for demonstrating bilinear interpolation
% Date      : 01-08-2012
% Creator   : Milind Padalkar
%   Inputs  :   1. Input image
%               2. X coordinate at which value is to be determined
%               3. X coordinate at which value is to be determined
%   Assumptions : Both x and y are non-integers
%   Outputs :   1. Value at img(x,y)
%   Usage   :   px_val = mgp_bilinear_interpolate(img,x,y)

%% Some theory
% Similar to linear interpolation
% |<---ty--->|
% P----------T1-----------Q
% |          T(x,y)       | tx
% |                       |
% R----------T2-----------S
% 
% Using linear interpolation determine,
% 1. T1 between P and Q
% 2. T2 between R and S
% 3. T between T1 and T2 which is the final desired result

%% Implementataion

if(floor(x)>0 && floor(y)>0)
    p = img(floor(x),floor(y));
else
    p = min(img(:));
end

if(floor(x)>0 && ceil(y)<=size(img,2))
    q = img(floor(x),ceil(y));
else
    q = min(img(:));
end

if(ceil(x)<=size(img,1) && floor(y)>0)
    r = img(ceil(x),floor(y));
else
    r = min(img(:));
end

if(ceil(x)<=size(img,1) && ceil(y)<=size(img,2))
    s = img(ceil(x),ceil(y));
else
    s = min(img(:));
end

tx = x-floor(x);
ty = y-floor(y);

t1 = mgp_linear_interpolate(p,q,ty);
t2 = mgp_linear_interpolate(r,s,ty);
t = mgp_linear_interpolate(t1,t2,tx);

px_val = t;
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
function r = mgp_linear_interpolate(p,q,ptor)
%% Function for demonstrating linear interpolation
% Date      : 01-08-2012
% Creator   : Milind Padalkar
%   Inputs  :   1. Starting value 'p' at point 'P'
%               2. Ending value 'q'at point 'Q'
%               3. Distance of 'R' from 'P'
%   Assumptions     :   Distance between p and q is 1
%   Outputs :   1. Value at 'R' i.e. r
%   Usage   :   r = mgp_linear_interpolate(p,q,ptor)

%% Some theory
% Given points 'P' and 'Q' with values 'p' and 'q' at 'T' units apart, i.e.
% (q-p)/T = 1 unit
% we intend to find the value 'r' of a point 'R' between them (or anywhere on 
% the line joining 'P' and 'Q') which is at 't' units from 'P'. Thus even
% (r-p)/t = 1 unit
% Hence, r = (((q-p)/T)*t)+p
T = 1;
t = ptor;
r = (((q-p)/T)*t)+p;
%--------------------------------------------------------------------------
