%   Computer Vision (IT524)
%   Assignment 3
%--------------------------------------------------------------------------
%   (b):
%   Statement: Use regularization based approach in (p,q) and (f,g) domains
%   to recover the shape. Use the gradient at x^2+y^2=r^2 with r=24 or 18 as
%   the initial conditions. How do the performances compare (w.r.t. actual p & q)?
%   From the estimated map recover the depth z(x,y).
%   How does the recovered depth compare with the actual depth?
%--------------------------------------------------------------------------
%   Created by: Milind Padalkar (201121015)
%   Date: 13-09-2012

%% Clear workspace
clear;
close all;
clc;

%% Set Parameters
rds = 24;                    % Sphere's radius
init_rds = 24;               % Radius of sphere for initial condition
sz = 64;                     % Image size
p_s = 0;                     % Source p_s
q_s = 0;                     % Source q_s
max_itrn = 100;             % maximum iterations (my default: 800)
z0 = 00;                     % Average depth
reg_lambda = 0.008;            % Regularization parameter (my default: 0.05)

%% Circle initialization
if(mod(sz,2)==0)
    mid = sz/2;
else
    mid = floor(sz/2) + 1;
end
sphr = zeros(sz,sz);

%% Calculating p and q and finally R(p(x,y),q(x,y)) = E(x,y)
%   Given
%   1. p = -x/(z-z0)
%   2. q = -y/(z-z0)
%   3. (z-z0)^2 + (x^2+y^2) = r^2
%   Thus,
%   E(x,y) = (p*p_s + q*q_s + 1)/(sqrt(p_s^2+q_s^2+1)*sqrt(p^2+q^2+1))
%
%          = ((-x/(z-z0))*ps + (-y/(z-z0))*qs + 1)
%            ---------------------------------------------------------------
%            ((sqrt(p_s^2+q_s^2+1)*sqrt((-x/(z-z0))^2+(-y/(z-z0))^2+1))
%
%   Therefore,
%   E(x,y) = (-x*p_s - y*q_s + (z-z0))/(r*sqrt(p_s*p_s+qs*q_s+1))
p_mat = zeros(sz,sz);
q_mat = zeros(sz,sz);
E = zeros(sz,sz);
ps = p_s(1);
qs = q_s(1);
for j = 1:sz
    y = mid - j;
    for i = 1:sz
        x = mid - i;
        if(x*x + y*y < rds*rds)
            z_z0 = sqrt(rds*rds-(x*x + y*y));
            p_mat(i,j) = -x/z_z0;
            q_mat(i,j) = -y/z_z0;
            E(i,j) = (-x*ps-y*qs+z_z0)/(rds*sqrt(ps*ps+qs*qs+1));
        end
    end
end
    
% % Display
% wintitle = sprintf('E(x,y) for source (ps,qs) = (%.1f,%.1f)',ps,qs);
% hdl_E = figure; imshow(E), title(wintitle);

%%  Calculation of Real Depth using Real values of p and q
%   Assuming the image plane to be kept at a distance z0 from the source,
%   we can consider z0 to be greater than the radius of the sphere.
%   Because p(x,y) = - z(x+1,y) + z(x,y), p(x-1,y) = - z(x,y) + z(x-1,y) and
%   q(x,y) = - z(x,y+1) + z(x,y), q(x,y) = - z(x,y) + z(x,y-1), we can write,
%   4*z(x,y) = (p(x,y)-p(x-1,y) + q(x,y) - q(x,y-1)) + ...
%              (z(x+1,y) + z(x-1,y) + z(x,y+1) + z(x,y-1))
%   Assuming some initial value for z matrix (let it be z0), after some
%   iterations the z matrix will not update, where one can stop.
z_old = ones(sz,sz)*z0;
z_mat = z_old;
itrn = 0;
while(1)
    itrn = itrn + 1;
    for j = 2:sz-1
        for i = 2:sz-1
            z_ngbh = z_old(i+1,j) + z_old(i-1,j) + z_old(i,j+1) + z_old(i,j-1);
            dpdq = p_mat(i,j)-p_mat(i-1,j)+q_mat(i,j)-q_mat(i,j-1);
            z_mat(i,j) = (1/4)*(dpdq + z_ngbh);
        end
    end
    if(z_mat==z_old)
        fprintf('Actual depth calcuation converged in %d iterations.\n',itrn);
        break;
    else
        z_old = z_mat;
    end
end

% hdl_zreal = figure; surf(z_mat), title('Real depth');

%% Initial conditions
pn = zeros(sz,sz);
qn = zeros(sz,sz);
for j = 1:sz
    y = mid - j;
    for i = 1:sz
        x = mid - i;
        if(x*x + y*y < init_rds^2)
            z_z0 = sqrt(init_rds^2-(x*x + y*y));
            pn(i,j) = -x/z_z0;
            qn(i,j) = -y/z_z0;
        end
    end
end
i_pn = pn;          % Starting P
i_qn = qn;          % Starting Q

%% Recovery of p and q
pn1 = i_pn.*0;          % New P
qn1 = i_qn.*0;          % New Q
orgE = E;               % Input image
itrn = 0;
sqrt_psqs = sqrt(ps.^2+qs.^2+1);
while(itrn<max_itrn)
    itrn = itrn + 1;
    for j = 2:sz-1
        for i = 2:sz-1    
            % Neighbourhood
            p_ngbh = (1/4)*(pn(i-1,j)+pn(i+1,j)+pn(i,j-1)+pn(i,j+1));
            q_ngbh = (1/4)*(qn(i-1,j)+qn(i+1,j)+qn(i,j-1)+qn(i,j+1));

            sqrt_pq = sqrt(pn(i,j).^2+qn(i,j).^2+1);

            % Rpq = R(p,q) = (p*ps+q*qs+1)/(sqrt(ps^2+qs^2+1)*(sqrt(p^2+q^2+1)))
            Rpq = (pn(i,j)*ps + qn(i,j)*qs + 1)/(sqrt_psqs*sqrt_pq);

            % dR/dp = Rp = (ps(q^2+1)-p(q*qs+1))/(sqrt(ps^2+qs^2+1)*(sqrt(p^2+q^2+1))^3)
            Rp = (ps*(qn(i,j).^2+1) - pn(i,j)*(qn(i,j)*qs+1))/(sqrt_psqs*(sqrt_pq^3));

            % dR/dq = Rq = (qs(p^2+1)-q(p*ps+1))/(sqrt(ps^2+qs^2+1)*(sqrt(p^2+q^2+1))^3)
            Rq = (qs*(pn(i,j).^2+1) - qn(i,j)*(pn(i,j)*ps+1))/(sqrt_psqs*(sqrt_pq^3));
            
            % New p and q
            pn1(i,j) = p_ngbh + (reg_lambda/4)*(orgE(i,j) - Rpq)*Rp;
            qn1(i,j) = q_ngbh + (reg_lambda/4)*(orgE(i,j) - Rpq)*Rq;
        end
    end
    if(pn1==pn & qn1==qn)
        fprintf('PQ recovery converged in %d iterations.\n',itrn);
        break;
    else
        pn = pn1;
        qn = qn1;
    end
end
hdl_recP = figure; imshow(pn1), title('Recovered P');
hdl_recQ = figure; imshow(qn1), title('Recovered q');

%% Depth estimation in PQ domain
z_old_pq = ones(sz,sz)*z0;
z_pq = z_old_pq;
itrn = 0;
while(1)
    itrn = itrn + 1;
    for j = 2:sz-1
        for i = 2:sz-1
            z_ngbh = z_old_pq(i+1,j)+z_old_pq(i-1,j)+z_old_pq(i,j+1)+z_old_pq(i,j-1);
            dpdq = pn1(i,j)-pn1(i-1,j)+qn1(i,j)-qn1(i,j-1);
            z_pq(i,j) = (1/4)*(dpdq + z_ngbh);
        end
    end
    if(z_pq==z_old_pq)
        fprintf('PQ depth calcuation converged in %d iterations.\n',itrn);
        break;
    else
        z_old_pq = z_pq;
    end
end

hdl_zPQ = figure; surf(z_pq), title('Recovered depth in PQ domain');

%% Error calculation in PQ domain
PQp_err = sum(sum((p_mat - pn1).^2));
PQq_err = sum(sum((q_mat - qn1).^2));
PQz_err = sum(sum((z_mat - z_pq).^2));
% 
% %% FG Initial conditions
% %   f = 2p/(1+sqrt(p^2+q^2+1))
% %   g = 2q/(1+sqrt(p^2+q^2+1))
% fn = zeros(sz,sz);
% gn = zeros(sz,sz);
% for j = 1:sz
%     for i = 1:sz
%         fn(i,j) = 2*i_pn(i,j)/(1+sqrt(i_pn(i,j).^2+i_qn(i,j).^2+1));
%         gn(i,j) = 2*i_qn(i,j)/(1+sqrt(i_pn(i,j).^2+i_qn(i,j).^2+1));
%     end
% end
% i_fn = fn;
% i_gn = gn;
% 
% %% Iterative calculation of F and G
% % Now, f = 2p/(1+sqrt(p^2+q^2+1)), g = 2q/(1+sqrt(p^2+q^2+1))
% % p = 4f/(4-(f^2+g^2)), q = 4g/(4-(f^2+g^2))
% % R(p,q) = (p*ps+q*qs+1)/(sqrt(ps^2+qs^+1)*sqrt(p^2+q^2+1))
% %        = (4*f*ps+4*g*qs+4-f^2-g^2)/(sqrt(ps^2+qs^2+1)*(4+f^2+g^2))
% %
% % dRf = (16*ps-4*ps*f^2+4*ps*g-16*f)/(sqrt(ps^2+qs^2+1)*((4+f^2+g^2)^2))
% % dRg = (16*qs-4*qs*g^2+4*qs*g-16*g)/(sqrt(ps^2+qs^2+1)*((4+f^2+g^2)^2))
% % fn1(i,j) = fn_avg(i,j) + (lambda/4)*(E-R)*dRf
% % gn1(i,j) = gn_avg(i,j) + (lambda/4)*(E-R)*dRg
% fn1 = i_fn.*0;
% gn1 = i_gn.*0;
% itrn = 0;
% while(itrn<max_itrn)
%     itrn = itrn + 1;   
%     for j = 2:sz-1
%         for i = 2:sz-1
%             % Neighbourhood
%             f_ngbh = (1/4)*(fn(i-1,j)+fn(i+1,j)+fn(i,j-1)+fn(i,j+1));
%             g_ngbh = (1/4)*(gn(i-1,j)+gn(i+1,j)+gn(i,j-1)+gn(i,j+1));
% 
%             sqr_sum_fg = fn(i,j)^2 + gn(i,j)^2;
% 
%             % Rpq = R(p,q) = = (4*f*ps+4*g*qs+4-f^2-g^2)/(sqrt(ps^2+qs^2+1)*(4+f^2+g^2))
%             Rfg = (4*fn(i,j)*ps + 4*gn(i,j)*qs + 4 - sqr_sum_fg)/(sqrt_psqs*(4 + sqr_sum_fg));
% 
%             % dR/df = Rf = (16*ps - 4*ps*f^2 + 4*ps*g^2 - 8*qs*f*g - 16*f)/(sqrt(ps^2+qs^2+1)*((4+f^2+g^2)^2))
%             Rf = (16*ps - 4*ps*(fn(i,j)^2) + 4*ps*(gn(i,j)^2) - 8*qs*fn(i,j)*gn(i,j) - 16*fn(i,j))/(sqrt_psqs*((4+sqr_sum_fg)^2));
% 
%             % dR/dg = Rg = (16*qs - 4*qs*g^2 + 4*qs*f^2 -8*ps*f*g - 16*g)/(sqrt(ps^2+qs^2+1)*((4+f^2+g^2)^2))
%             Rg = (16*qs - 4*qs*(gn(i,j)^2) + 4*qs*(fn(i,j)^2) - 8*ps*gn(i,j)*fn(i,j) - 16*gn(i,j))/(sqrt_psqs*((4+sqr_sum_fg)^2));
%             
%             % New f and g
%             fn1(i,j) = f_ngbh + (reg_lambda/4)*(orgE(i,j) - Rfg)*Rf;
%             gn1(i,j) = g_ngbh + (reg_lambda/4)*(orgE(i,j) - Rfg)*Rg;
%         end
%     end
%     
%     if(fn1==fn & gn1==gn)
%         fprintf('FG recovery converged in %d iterations.\n',itrn);
%         break;
%     else
%         fn = fn1;
%         gn = gn1;
%     end
% end
% 
% hdl_recF = figure; imshow(fn1), title('Recovered F');
% hdl_recG = figure; imshow(gn1), title('Recovered G');
% 
% %% p,q recovery in FG domain
% %   p = 4f/(4-f^2-g^2)
% %   q = 4g/(4-f^2-g^2)
% pn1f = i_fn.*0;
% qn1g = i_gn.*0;
% for i = 1:sz
%     for j = 1:sz
%         pn1f(i,j) = 4*fn1(i,j)/(4-(fn1(i,j)^2)-(gn1(i,j)^2));
%         qn1g(i,j) = 4*gn1(i,j)/(4-(fn1(i,j)^2)-(gn1(i,j)^2));
%     end
% end
% 
% %% Depth calculation in FG domain using estimated PQ
% % z_old_fg = ones(sz,sz);
% % z_fg = zeros(sz,sz);
% z_old_fg = ones(sz,sz)*z0;
% z_fg = z_old_fg;
% itrn = 0;
% while(1)
%     itrn = itrn + 1;
%     for j = 2:sz-1
%         for i = 2:sz-1
%             z_ngbh = z_old_fg(i+1,j)+z_old_fg(i-1,j)+z_old_fg(i,j+1)+z_old_fg(i,j-1);
%             dpdq = pn1f(i,j)-pn1f(i-1,j)+qn1g(i,j)-qn1g(i,j-1);
%             z_fg(i,j) = (1/4)*(dpdq + z_ngbh);
%         end
%     end
%     if(z_fg==z_old_fg)
%         fprintf('FG depth calcuation converged in %d iterations.\n',itrn);
%         break;
%     else
%         z_old_fg = z_fg;
%     end
% end
% 
% hdl_zFG = figure; surf(z_fg), title('Recovered depth in FG domain');
% 
% %% Error calculation in PQ domain
% FGp_err = sum(sum((p_mat - pn1f).^2));
% FGq_err = sum(sum((q_mat - qn1g).^2));
% FGz_err = sum(sum((z_mat - z_fg).^2));
% 
% % %% Show error comparison
% % fprintf('PQp_err = %f\tFGp_err = %f\n',PQp_err,FGp_err);
% % fprintf('PQq_err = %f\tFGq_err = %f\n',PQq_err,FGq_err);
% % fprintf('PQz_err = %f\tFGz_err = %f\n',PQz_err,FGz_err);