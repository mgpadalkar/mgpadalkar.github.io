%   Assignment 2 : Implementation of Shape from Shading with given 8 source
%   positions
%   Use z = z0 + sqrt(r^2 - (x^2 + y^2))
clear all;
close all;
clc;

%%   Parameters
rds = 25;
sz = 64;
ps_ary = [0.8389;0.5773;0.3638;0.1763;-0.1763;-0.3638;-0.5773;-0.8389];
qs_ary = [0.7193;0.6363;0.5865;0.5596;-0.5596;-0.5865;-0.6363;-0.7193];
num_src = length(ps_ary);
%%   Circle initialization
if(mod(sz,2)==0)
    mid = sz/2;
else
    mid = floor(sz/2) + 1;
end
sphr = zeros(sz,sz);

%%   Drawing the sphere
for j = 1:sz
    y = mid - j;
    for i = 1:sz
        x = mid - i;
        if(x*x + y*y <= rds*rds)
            sphr(i,j) = 1;
        end
    end
end
% figure, imshow(sphr), title('Sphere in 2D');

%%  Calculation of true values of p(x,y) and q(x,y) using
%   z = z0 + sqrt(rds*rds - (x*x+y*y));
%   p = -x/(z-z0) and q = -y/(z-z0)
%   Neglecting the points where (z-z0) = 0
p = zeros(sz,sz);
q = zeros(sz,sz);
for j = 1:sz
    y = mid - j;
    for i = 1:sz
        x = mid - i;
        if(x*x+y*y<rds*rds)
            z_z0 = sqrt(rds*rds-(x*x + y*y));
%             if(z_z0 == 0)
%                 z_z0 = eps;
%             end
            p(i,j) = -x/z_z0;
            q(i,j) = -y/z_z0;
        end
    end
end
figure, imshow(abs(p)), title('True p(x,y)');
figure, imshow(abs(q)), title('True q(x,y)');


%%  Calculation of E(x,y) for each source position
%   p = -x/(z-z0) and q = -y/(z-z0);    (z-z0)^2 + (x^2+y^2) = r^2
%   E(x,y) = (p*ps + q*qs + 1)/(sqrt(ps^2+qs^2+1)*sqrt(p^2+q^2+1))
%          = ((-x/(z-z0))*ps + (-y/(z-z0))*qs + 1)
%            ---------------------------------------------------------------
%            ((sqrt(ps^2+qs^2+1)*sqrt((-x/(z-z0))^(-x/(z-z0))+(-y/(z-z0))*(-y/(z-z0))+1))
%          = (-x*ps - y*qs + (z-z0))/(r*sqrt(ps*ps+qs*qs+1))
E = zeros(sz,sz,num_src);
for pln = 1:num_src
    ps = ps_ary(pln,1);
    qs = qs_ary(pln,1);
    for j = 1:sz
        y = mid - j;
        for i = 1:sz
            x = mid - i;
            if(x*x + y*y < rds*rds)
                z_z0 = sqrt(rds*rds-(x*x + y*y));
                E(i,j,pln) = (-x*ps-y*qs+z_z0)/(rds*sqrt(ps*ps+qs*qs+1));
            end
        end
    end
    figure, imshow(E(:,:,pln)), title(sprintf('Image with source position [%f,%f]',ps,qs));
end

%%  Calculation of S matrix which is (num_src)x(3)
S = zeros(num_src,3);
for pln = 1:length(ps_ary)
    ps = ps_ary(pln,1);
    qs = qs_ary(pln,1);
    denom = sqrt(ps*ps+qs*qs+1);
    S(pln,1) = (-1)*ps/denom;
    S(pln,2) = (-1)*qs/denom;
    S(pln,3) = 1/denom;
end

%%  Calculation of S_inverse using SVD for solving S*n = Exy
[u s v] = svd(S);
st = s';
inv_st = 1./st;
inv_st(~isfinite(inv_st)) = 0;
inv_S = v*inv_st*u';

%%  Calculation of p_cap and q_cap using E(x,y) and S matrix
p_cap = zeros(sz,sz);
q_cap = zeros(sz,sz);
for j = 1:sz
    y = mid - j;
    for i = 1:sz
        x = mid - i;
        if(x*x+y*y<rds*rds)
            Exy = reshape(E(i,j,:),num_src,1);
            %%  Now Exy = S*n   assuming rho = 1,   n = inv_S*Exy
            %   n(1,1) = (-1)*p/(p*p+q*q+1)
            %   n(2,1) = (-1)*q/(p*p+q*q+1)
            %   n(3,1) = 1/(p*p+q*q+1)
            n = inv_S*Exy;
            if(n(3,1)==0)
                n(3,1) = eps;
            end
            p_cap(i,j) = (-1)*(n(1,1)/n(3,1));
            q_cap(i,j) = (-1)*(n(2,1)/n(3,1));
        end
    end
end
figure, imshow(abs(p_cap)), title('p\_cap');
figure, imshow(abs(q_cap)), title('q\_cap');


%%  Calculation of Real Depth using Real values of p and q
%   Assuming the image plane to be kept at a distance z0 from the source,
%   we can consider z0 to be greater than the radius of the sphere.
%   Because p(x,y) = z(x+1,y) - z(x,y), p(x-1,y) = z(x,y) - z(x-1,y) and
%   q(x,y) = z(x,y+1) - z(x,y), q(x,y) = z(x,y) - z(x,y-1), we can write,
%   4*z(x,y) = (p(x-1,y)-p(x,y) + q(x,y-1) - q(x,y)) + ...
%              (z(x+1,y) + z(x-1,y) + z(x,y+1) + z(x,y-1))
%   Assuming some initial value for z matrix (let it be z0), after some
%   iterations the z matrix will not update, where one can stop.
z0 = 50;
z = ones(sz,sz)*z0;
z_old = z;
itrn = 0;
while(1)
    itrn = itrn + 1;
    for j = 1:sz
        y = mid - j;
        for i = 1:sz
            x = mid - i;
            if(x*x+y*y<rds*rds)
                z(i,j) = (p(i,j)-p(i-1,j)+q(i,j)-q(i,j-1)+...
                    z_old(i+1,j)+z_old(i-1,j)+z_old(i,j+1)+z_old(i,j-1))*(1/4);
            end
        end
    end
    if(z==z_old)
        break;
    else
        z_old = z;
    end
end
figure, surf(z), title('True Depth');

%%  Calculation of Depth using recovered values viz p_cap and q_cap
% Just as above, z_cap can be calculated in a manner similar to that of
% obtaining z
z_cap = ones(sz,sz)*z0;
z_old = z;
itrn = 0;
while(1)
    itrn = itrn + 1;
    for j = 1:sz
        y = mid - j;
        for i = 1:sz
            x = mid - i;
            if(x*x+y*y<rds*rds)
                z_cap(i,j) = (p_cap(i,j)-p_cap(i-1,j)+q_cap(i,j)-q_cap(i,j-1)+...
                    z_old(i+1,j)+z_old(i-1,j)+z_old(i,j+1)+z_old(i,j-1))*(1/4);
            end
        end
    end
    if(z_cap==z_old)
        break;
    else
        z_old = z_cap;
    end
end
figure, surf(z_cap), title('Recovered Depth');

%%  Various squrared errors
p_error = sum(sum((p-p_cap).*(p-p_cap)));
q_error = sum(sum((q-q_cap).*(q-q_cap)));
z_error = sum(sum((z-z_cap).*(z-z_cap)));
% figure, imshow(abs(p_error)), title('Error in P');
% figure, imshow(abs(q_error)), title('Error in Q');
% figure, imshow(abs(z_error)), title('Error in Z');

%%  Alternate calculation of real depth, assuming some value for average depth
%   z-z0 = sqrt(rds*rds-(x*x+y*y));, but for a sphere x*x+y*y+w*w =rds*rds
%   So, w = +-sqrt(rds*rds-(x*x+y*y)) i.e. z-z0 = +-w and z = z0 +- w
%   Since we can see only rear half of sphere, we will plot the depth for
%   only this half
z0 = 50;    % Always greater than radius, else source is inside the sphere
z_alt = ones(sz,sz)*z0;
for j = 1:sz
    y = mid - j;
    for i = 1:sz
        x = mid - i;
        if(x*x+y*y<rds*rds)
            w = sqrt(rds*rds - (x*x+y*y));
            z_alt(i,j) = z0 + w;
        end
    end
end
figure, surf(z_alt), title('Real Depth by alternate method');

%%  Alternate calculation of depth using the recovered values of p and q
%   viz. p_cap and q_cap respectively (or p_cap(x,y) and q_cap(x,y))
%   z-z0 = -x/p_cap     and     z-z0 = -y/q_cap
%   So, 2(z-z0) = -x/p_cap - y/q_cap i.e. z-z0 = (1/2)*(-x/p_cap-y-q_cap)
%   Assuming some default value for z0, z = z0 - (1/2)*(x/p_cap+y/q_cap)
%   For front half of the sphere, z0, z = z0 + (1/2)*(x/p_cap+y/q_cap)
z_cap_alt = ones(sz,sz)*z0;
for j = 1:sz
    y = mid - j;
    for i = 1:sz
        x = mid - i;
        if(x*x+y*y<rds*rds)
            %%  To handle divide by zero
            if(p_cap(i,j)==0)
                denom_p = eps;
            else
                denom_p = p_cap(i,j);
            end
            if(q_cap(i,j)==0)
                denom_q = eps;
            else
                denom_q = q_cap(i,j);
            end
            %%  Actual calculation of z_cap
            z_cap_alt(i,j) = z0 - (1/2)*(x/denom_p+y/denom_q);
        end
    end
end
figure, surf(z_cap_alt), title('Recovered Depth by alternate method');