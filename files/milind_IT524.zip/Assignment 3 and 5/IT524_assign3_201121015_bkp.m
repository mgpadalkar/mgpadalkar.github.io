%   Computer Vision (IT524)
%   Assignment 3
%--------------------------------------------------------------------------
%   (a):
%   Statement: Consider a hemispherical surface z(x,y) = sqrt(r^2-x^2-y^2) + z0.
%   Select an image of size 64x64. With the origin as the centre, and r=24 (say),
%   find the surface normal representing the gradients p(x,y) and q(x,y) analytically.
%   Assume the surface to be Lambertian. The object is illuminated by a point
%   light source with (ps,qs)=(0,0). Generate the corresponding image.
%--------------------------------------------------------------------------
%   (b):
%   Statement: Use regularization based approach in (p,q) and (f,g) domains
%   to recover the shape. Use the gradient at x^2+y^2=r^2 with r=24 or 18 as
%   the initial conditions. How do the performances compare (w.r.t. actual p & q)?
%   From the estimated map recover the depth z(x,y).
%   How does the recovered depth compare with the actual depth?
%--------------------------------------------------------------------------
%   Created by: Milind Padalkar (201121015)
%   Date: 13-09-2012

%% Clear workspace
clear;
close all;
clc;

%% Part (a)
%--------------------------------------------------------------------------
%% Set Parameters
rds = 24;           % Sphere's radius
sz = 64;            % Image size
p_s = 0;      % Source p_s
q_s = 0;      % Source q_s

%% Circle initialization
if(mod(sz,2)==0)
    mid = sz/2;
else
    mid = floor(sz/2) + 1;
end
sphr = zeros(sz,sz);

%% Draw the sphere
for j = 1:sz
    y = mid - j;
    for i = 1:sz
        x = mid - i;
        if(x*x + y*y <= rds*rds)
            sphr(i,j) = 1;
        end
    end
end
% hdl2D = figure; imshow(sphr), title('Sphere in 2D');

%% Calculating p and q and finally R(p(x,y),q(x,y)) = E(x,y)
%   Given
%   1. p = -x/(z-z0)
%   2. q = -y/(z-z0)
%   3. (z-z0)^2 + (x^2+y^2) = r^2
%   Thus,
%   E(x,y) = (p*p_s + q*q_s + 1)/(sqrt(p_s^2+q_s^2+1)*sqrt(p^2+q^2+1))
%
%          = ((-x/(z-z0))*ps + (-y/(z-z0))*qs + 1)
%            ---------------------------------------------------------------
%            ((sqrt(p_s^2+q_s^2+1)*sqrt((-x/(z-z0))^2+(-y/(z-z0))^2+1))
%
%   Therefore,
%   E(x,y) = (-x*p_s - y*q_s + (z-z0))/(r*sqrt(p_s*p_s+qs*q_s+1))
for srcs = 1:size(p_s,2)
    E = zeros(sz,sz);
    ps = p_s(srcs);
    qs = q_s(srcs);
    for j = 1:sz
        y = mid - j;
        for i = 1:sz
            x = mid - i;
            if(x*x + y*y <= rds*rds)
                z_z0 = sqrt(rds*rds-(x*x + y*y));
                E(i,j) = (-x*ps-y*qs+z_z0)/(rds*sqrt(ps*ps+qs*qs+1));
            end
        end
    end
    
    % Display
    wintitle = sprintf('E(x,y) for source (ps,qs) = (%.1f,%.1f)',ps,qs);
%     hdlE = figure; imshow(E), title(wintitle);
    
%     % Save
%     print(hdlE,'-v','-dpng',sprintf('Source_%d.png',srcs));
%     print(hdl2D,'-v','-dpng',sprintf('Sphere in 2D_%d.png',srcs));
end
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
%%  Part (b) : PQ domain
%% Actual p and q and z
% Assumption: Value of z0
ps = p_s(1);
qs = q_s(1);
sqrt_psqs = sqrt(ps.^2+qs.^2+1);
p_mat = zeros(sz,sz);
q_mat = zeros(sz,sz);
z0 = 0;
z_mat = ones(sz,sz).*Inf;
for j = 1:sz
    y = mid - j;
    for i = 1:sz
        x = mid - i;
        if(x*x + y*y < rds*rds)
            z_z0 = sqrt(rds*rds-(x*x + y*y));
            p_mat(i,j) = -x/z_z0;
            q_mat(i,j) = -y/z_z0;
            z_mat(i,j) = z_z0 + z0;
        end
    end
end

% hdlP = figure; imshow(p_mat), title('Actual P');
% hdlQ = figure; imshow(q_mat), title('Actual Q');
% hdlZ = figure; surf(z_mat), title('Actual Depth');
% 
% % Save
% print(hdlP,'-v','-dpng',sprintf('Actual P'));
% print(hdlQ,'-v','-dpng',sprintf('Actual Q'));
% print(hdlZ,'-v','-dpng',sprintf('Actual Depth'));

%% Initial conditions
pn = zeros(sz,sz);
qn = zeros(sz,sz);
rds2 = rds-1;
for j = 1:sz
    y = mid - j;
    for i = 1:sz
        x = mid - i;
        if(x*x + y*y < rds2*rds2)
            z_z0 = sqrt(rds2*rds2-(x*x + y*y));
            pn(i,j) = -x/z_z0;
            qn(i,j) = -y/z_z0;
        end
    end
end
i_pn = pn;
i_qn = qn;
% pn = imnoise(pn,'gaussian');
% qn = imnoise(qn,'gaussian');
% pn = ones(sz,sz)*10;
% qn = ones(sz,sz)*10;

% figure, imshow(i_pn), title('Initial P');
% figure, imshow(i_qn), title('Initial Q');

pn1 = pn.*0;
qn1 = qn.*0;
reg_lambda = 0.0001;
orgE = E;
max_itrn = 1000;
itrn = 0;

%% Iterative calculation of p and q
while(itrn<max_itrn)
    itrn = itrn + 1;
    fprintf('Itration = %d\n',itrn);
    
    for j = 2:sz-1
        for i = 2:sz-1    
            % Neighbourhood
            p_ngbh = (1/4)*(pn(i-1,j)+pn(i+1,j)+pn(i,j-1)+pn(i,j+1));
            q_ngbh = (1/4)*(qn(i-1,j)+qn(i+1,j)+qn(i,j-1)+qn(i,j+1));

            sqrt_pq = sqrt(pn(i,j).^2+qn(i,j).^2+1);

            % Rpq = R(p,q) = (p*ps+q*qs+1)/(sqrt(ps^2+qs^2+1)*(sqrt(p^2+q^2+1)))
            Rpq = (pn(i,j)*ps + qn(i,j)*qs + 1)/(sqrt_psqs*sqrt_pq);

            % dR/dp = Rp = (ps(q^2+1)-p(q*qs+1))/(sqrt(ps^2+qs^2+1)*(sqrt(p^2+q^2+1))^3)
            Rp = (ps*(qn(i,j).^2+1) - pn(i,j)*(qn(i,j)*qs+1))/(sqrt_psqs*(sqrt_pq^3));

            % dR/dq = Rq = (qs(p^2+1)-q(p*ps+1))/(sqrt(ps^2+qs^2+1)*(sqrt(p^2+q^2+1))^3)
            Rq = (qs*(pn(i,j).^2+1) - qn(i,j)*(pn(i,j)*ps+1))/(sqrt_psqs*(sqrt_pq^3));
            
            % New p and q
            pn1(i,j) = p_ngbh + (reg_lambda/4)*(orgE(i,j) - Rpq)*Rp;
            qn1(i,j) = q_ngbh + (reg_lambda/4)*(orgE(i,j) - Rpq)*Rq;
        end
    end
    
    if(pn1==pn | qn1==qn)
        itrn = max_itrn;
    else
        pn = pn1;
        qn = qn1;
    end
    
end

% figure, imshow(pn1), title('Recovered P');
% figure, imshow(qn1), title('Recovered Q');

% Depth calculation by iterative method in pq domain
zn = ones(sz,sz);
zn1 = ones(sz,sz);
itrn = 0;
while(itrn<max_itrn)
    itrn = itrn + 1;
    fprintf('Itration2 = %d\n',itrn);
    for j = 2:sz-1
        for i = 2:sz-1 
            zn1(i,j) = (1/4)*(zn(i+1,j) + zn(i-1,j) + zn(i,j+1) + zn(i,j-1)) + (pn1(i,j)-pn1(i-1,j)) + (qn1(i,j)-qn1(i,j-1));
        end
    end
    if(zn1==zn)
        itrn = max_itrn;
    else
        zn = zn1;
    end
end
zn1 = zn1 + z0;
% figure, surf(zn1), title('Recovered Depth in PQ domain');

%%  Part (b) : FG domain

%% Actual F and G from actual P and Q
f_mat = zeros(sz,sz);
g_mat = zeros(sz,sz);
for j = 1:sz
    for i = 1:sz
        f_mat(i,j) = 2*p_mat(i,j)/(1+sqrt(p_mat(i,j).^2+q_mat(i,j).^2+1));
        g_mat(i,j) = 2*q_mat(i,j)/(1+sqrt(p_mat(i,j).^2+q_mat(i,j).^2+1));
    end
end
% hdlF = figure; imshow(f_mat), title('Actual F');
% hdlG = figure; imshow(g_mat), title('Actual G');

%% Initial conditions
fn = zeros(sz,sz);
gn = zeros(sz,sz);
fn1 = fn.*0;
gn1 = gn.*0;
% orgE = imnoise(E,'gaussian',0,0.001);
for j = 1:sz
    for i = 1:sz
        fn(i,j) = 2*i_pn(i,j)/(1+sqrt(i_pn(i,j).^2+i_qn(i,j).^2+1));
        gn(i,j) = 2*i_qn(i,j)/(1+sqrt(i_pn(i,j).^2+i_qn(i,j).^2+1));
    end
end
i_fn = fn;
i_gn = gn;
figure, imshow(fn), title('Initial F');
figure, imshow(gn), title('Initial G');

%% Iterative calculation of F and G
% Now, f = 2p/(1+sqrt(p^2+q^2+1)), g = 2q/(1+sqrt(p^2+q^2+1))
% p = 4f/(4-(f^2+g^2)), q = 4g/(4-(f^2+g^2))
% R(p,q) = (p*ps+q*qs+1)/(sqrt(ps^2+qs^+1)*sqrt(p^2+q^2+1))
%        = (4*f*ps+4*g*qs+4-f^2-g^2)/(sqrt(ps^2+qs^2+1)*(4+f^2+g^2))
%
% dRf = (16*ps-4*ps*f^2+4*ps*g-16*f)/(sqrt(ps^2+qs^2+1)*((4+f^2+g^2)^2))
% dRg = (16*qs-4*qs*g^2+4*qs*g-16*g)/(sqrt(ps^2+qs^2+1)*((4+f^2+g^2)^2))
% fn1(i,j) = fn_avg(i,j) + (lambda/4)*(E-R)*dRf
% gn1(i,j) = gn_avg(i,j) + (lambda/4)*(E-R)*dRg
itrn = 0;
while(itrn<max_itrn)
    itrn = itrn + 1;
    fprintf('Itration = %d\n',itrn);
    
    for j = 2:sz-1
        for i = 2:sz-1
            % Neighbourhood
            f_ngbh = (1/4)*(fn(i-1,j)+fn(i+1,j)+fn(i,j-1)+fn(i,j+1));
            g_ngbh = (1/4)*(gn(i-1,j)+gn(i+1,j)+gn(i,j-1)+gn(i,j+1));

            sqr_sum_fg = fn(i,j)^2 + gn(i,j)^2;

            % Rpq = R(p,q) = = (4*f*ps+4*g*qs+4-f^2-g^2)/(sqrt(ps^2+qs^2+1)*(4+f^2+g^2))
            Rfg = (4*fn(i,j)*ps + 4*gn(i,j)*qs + 4 - sqr_sum_fg)/(sqrt_psqs*(4 + sqr_sum_fg));

            % dR/df = Rf = (16*ps-4*ps*f^2+4*ps*g-16*f)/(sqrt(ps^2+qs^2+1)*((4+f^2+g^2)^2))
            Rf = (16*ps - 4*ps*(fn(i,j)^2) + 4*ps*gn(i,j) - 16*fn(i,j))/(sqrt_psqs*((4+sqr_sum_fg)^2));

            % dR/dg = Rg = (16*qs-4*qs*g^2+4*qs*g-16*g)/(sqrt(ps^2+qs^2+1)*((4+f^2+g^2)^2))
            Rg = (16*qs - 4*qs*(gn(i,j)^2) + 4*qs*fn(i,j) - 16*gn(i,j))/(sqrt_psqs*((4+sqr_sum_fg)^2));
            
            % New p and q
            fn1(i,j) = f_ngbh + (reg_lambda/4)*(orgE(i,j) - Rfg)*Rf;
            gn1(i,j) = g_ngbh + (reg_lambda/4)*(orgE(i,j) - Rfg)*Rg;
        end
    end
    
    if(fn1==fn | gn1==gn)
        itrn = max_itrn;
    else
        fn = fn1;
        gn = gn1;
    end
end

figure, imshow(fn1), title('Recovered F');
figure, imshow(gn1), title('Recovered G');

%% Recover P and Q from F and G
pn1f = fn.*0;
qn1g = gn.*0;
for i = 1:sz
    for j = 1:sz
        pn1f(i,j) = 4*fn1(i,j)/(4-(fn1(i,j)^2)-(gn1(i,j)^2));
        qn1g(i,j) = 4*gn1(i,j)/(4-(fn1(i,j)^2)-(gn1(i,j)^2));
    end
end

figure, imshow(pn1f), title('Recovered P');
figure, imshow(qn1g), title('Recovered Q');

% Depth calculation by iterative method in FG domain using estimated PQ
znfg = ones(sz,sz);
zn1fg = zeros(sz,sz);
itrn = 0;
while(itrn<max_itrn)
    itrn = itrn + 1;
    fprintf('Itration2 = %d\n',itrn);
    for j = 2:sz-1
        for i = 2:sz-1 
            zn1fg(i,j) = (1/4)*(znfg(i+1,j) + znfg(i-1,j) + znfg(i,j+1) + znfg(i,j-1)) + (pn1f(i,j)-pn1f(i-1,j)) + (qn1g(i,j)-qn1g(i,j-1));
        end
    end
    znfg = zn1fg;
end
zn1fg = zn1fg + z0;
figure, surf(zn1fg), title('Recovered Depth in FG domain');

%--------------------------------------------------------------------------