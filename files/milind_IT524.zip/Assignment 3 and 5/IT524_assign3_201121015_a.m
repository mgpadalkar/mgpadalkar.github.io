%   Computer Vision (IT524)
%   Assignment 3
%--------------------------------------------------------------------------
%   (a):
%   Statement: Consider a hemispherical surface z(x,y) = sqrt(r^2-x^2-y^2) + z0.
%   Select an image of size 64x64. With the origin as the centre, and r=24 (say),
%   find the surface normal representing the gradients p(x,y) and q(x,y) analytically.
%   Assume the surface to be Lambertian. The object is illuminated by a point
%   light source with (ps,qs)=(0,0). Generate the corresponding image.
%--------------------------------------------------------------------------
%   Created by: Milind Padalkar (201121015)
%   Date: 13-09-2012

%% Clear workspace
clear;
close all;
clc;

%% Set Parameters
rds = 24;                    % Sphere's radius
sz = 64;                     % Image size
p_s = 0;                     % Source p_s
q_s = 0;                     % Source q_s
max_itrn = 1000;             % maximum iterations (500)
z0 = 00;                     % Average depth

%% Circle initialization
if(mod(sz,2)==0)
    mid = sz/2;
else
    mid = floor(sz/2) + 1;
end
sphr = zeros(sz,sz);

% Draw the sphere
for j = 1:sz
    y = mid - j;
    for i = 1:sz
        x = mid - i;
        if(x*x + y*y <= rds*rds)
            sphr(i,j) = 1;
        end
    end
end
hdl_sphr = figure; imshow(sphr), title('Sphere in 2D');

%% Calculating p and q and finally R(p(x,y),q(x,y)) = E(x,y)
%   Given
%   1. p = -x/(z-z0)
%   2. q = -y/(z-z0)
%   3. (z-z0)^2 + (x^2+y^2) = r^2
%   Thus,
%   E(x,y) = (p*p_s + q*q_s + 1)/(sqrt(p_s^2+q_s^2+1)*sqrt(p^2+q^2+1))
%
%          = ((-x/(z-z0))*ps + (-y/(z-z0))*qs + 1)
%            ---------------------------------------------------------------
%            ((sqrt(p_s^2+q_s^2+1)*sqrt((-x/(z-z0))^2+(-y/(z-z0))^2+1))
%
%   Therefore,
%   E(x,y) = (-x*p_s - y*q_s + (z-z0))/(r*sqrt(p_s*p_s+qs*q_s+1))
p_mat = zeros(sz,sz);
q_mat = zeros(sz,sz);
E = zeros(sz,sz);
ps = p_s(1);
qs = q_s(1);
for j = 1:sz
    y = mid - j;
    for i = 1:sz
        x = mid - i;
        if(x*x + y*y < rds*rds)
            z_z0 = sqrt(rds*rds-(x*x + y*y));
            p_mat(i,j) = -x/z_z0;
            q_mat(i,j) = -y/z_z0;
            E(i,j) = (-x*ps-y*qs+z_z0)/(rds*sqrt(ps*ps+qs*qs+1));
        end
    end
end
    
% Display
wintitle = sprintf('E(x,y) for source (ps,qs) = (%.1f,%.1f)',ps,qs);
hdl_E = figure; imshow(E), title(wintitle);

%%  Calculation of Real Depth using Real values of p and q
%   Assuming the image plane to be kept at a distance z0 from the source,
%   we can consider z0 to be greater than the radius of the sphere.
%   Because p(x,y) = - z(x+1,y) + z(x,y), p(x-1,y) = - z(x,y) + z(x-1,y) and
%   q(x,y) = - z(x,y+1) + z(x,y), q(x,y) = - z(x,y) + z(x,y-1), we can write,
%   4*z(x,y) = (p(x,y)-p(x-1,y) + q(x,y) - q(x,y-1)) + ...
%              (z(x+1,y) + z(x-1,y) + z(x,y+1) + z(x,y-1))
%   Assuming some initial value for z matrix (let it be z0), after some
%   iterations the z matrix will not update, where one can stop.
z_old = ones(sz,sz)*z0;
z_mat = z_old;
itrn = 0;
while(1)
    itrn = itrn + 1;
    for j = 2:sz-1
        for i = 2:sz-1
            z_ngbh = z_old(i+1,j) + z_old(i-1,j) + z_old(i,j+1) + z_old(i,j-1);
            dpdq = p_mat(i,j)-p_mat(i-1,j)+q_mat(i,j)-q_mat(i,j-1);
            z_mat(i,j) = (1/4)*(dpdq + z_ngbh);
        end
    end
    if(z_mat==z_old)
        fprintf('Actual depth calcuation converged in %d iterations.\n',itrn);
        break;
    else
        z_old = z_mat;
    end
end

hdl_zreal = figure; surf(z_mat), title('Real depth');


%% Save all figures (print command)
print(hdl_sphr,'-v','-dpng', './Results (a)/sphere.png');
print(hdl_E,'-v','-dpng', './Results (a)/shade.png');
print(hdl_zreal,'-v','-dpng', './Results (a)/depth.png');
close all;