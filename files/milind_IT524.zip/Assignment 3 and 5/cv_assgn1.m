%   Assignment 1 : Implementation of Shape from Shading
%   Use z = z0 + sqrt(r^2 - (x^2 + y^2))
%   Assume different source positions viz. (ps,qs) = (0,0), (0.5,0.5) etc
clear all;
close all;
clc;

%   Parameters
rds = 25;
sz = 64;
ps = [0;0.5;1];
qs = [0;0.5;0];

%   Circle initialization
if(mod(sz,2)==0)
    mid = sz/2;
else
    mid = floor(sz/2) + 1;
end
sphr = zeros(sz,sz);

%   Draw the sphere
for j = 1:sz
    y = mid - j;
    for i = 1:sz
        x = mid - i;
        if(x*x + y*y <= rds*rds)
            sphr(i,j) = 1;
        end
    end
end
figure, imshow(sphr), title('Sphere in 2D');

%   p = -x/(z-z0) and q = -y/(z-z0);    (z-z0)^2 + (x^2+y^2) = r^2
%   E(x,y) = (p*ps + q*qs + 1)/(sqrt(ps^2+qs^2+1)*sqrt(p^2+q^2+1))
%          = ((-x/(z-z0))*ps + (-y/(z-z0))*qs + 1)
%            ---------------------------------------------------------------
%            ((sqrt(ps^2+qs^2+1)*sqrt((-x/(z-z0))^(-x/(z-z0))+(-y/(z-z0))*(-y/(z-z0))+1))
%          = (-x*ps - y*qs + (z-z0))/(r*sqrt(ps*ps+qs*qs+1))
E = zeros(sz,sz);
ps = ps(2);
qs = qs(2);
for j = 1:sz
    y = mid - j;
    for i = 1:sz
        x = mid - i;
        if(x*x + y*y <= rds*rds)
            z_z0 = sqrt(rds*rds-(x*x + y*y));
            E(i,j) = (-x*ps-y*qs+z_z0)/(rds*sqrt(ps*ps+qs*qs+1));
        end
    end
end
figure, imshow(E), title('E(x,y)');